# Workshop 2

::::::{versionadded} v2025.2.0 After workshop 2
Solutions workshop 2 in downloads 
::::::

::::::{attention}
This pages shows a preview of the assignment including its solution. Please fork and clone the assignment to work on it locally from [GitHub](https://github.com/CIEM5000-2025/practice-assignments)
::::::

During today's workshop you'll extend your implementation of the matrix method.

```{custom_download_link} https://github.com/CIEM5000-2025/practice-assignments
:text: "All files practice assignments"
:replace_default: "False"
```

```{custom_download_link} https://github.com/CIEM5000-2025/practice-assignments/tree/solution_workshop_2
:text: "All files practice assignments with solutions workshop 2"
:replace_default: "False"
```