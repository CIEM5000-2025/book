# Lecture 2

During today's lesson you'll wrap up the discussion on the Matrix Method for statics and implement in code some new content. You'll be given the last theoretical details of the method, including how to consider element loads, non-zero Dirichlet boundary conditions and postprocessing for support reactions and element fields.

This lecture is given by Iuri Rocha.

This book shows the full content of the first lecture. The slides of the lecture have the same content and are available [here](./Lecture2.pdf)