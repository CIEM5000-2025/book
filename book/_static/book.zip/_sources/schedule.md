# Course schedule 📅

See the schedule below for the different weeks. Clicking the links will take you to the relevant content pages.

|Week|Monday|Tuesday|Thursday|
|:-:|:-:|:-:|:-:|
|1|| [](lecture1.md) | [](workshop1.md)|
|2|| [](lecture2.md) | [](workshop2.md), at any moment after workshop 2: [](additional.md)|
|7||| Question hour of all parts of CIEM5000 |
|8||| Question hour of all parts of CIEM5000|
|April 18th, 23:59|Hand in report: [](./assignment.md)|
|June 20th, 23:59|Hand in report for resit: [](./assignment.md)|