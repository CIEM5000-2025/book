# Workshop 1

```{custom_download_link} https://github.com/CIEM5000-2025/practice-assignments
:text: "All files practice assignments"
:replace_default: "False"
```

```{custom_download_link} https://github.com/CIEM5000-2025/practice-assignments/tree/solution_workshop_1
:text: "All files practice assignments solutions workshop 1"
:replace_default: "False"
```

::::::{versionadded} v2025.1.0 After workshop 1
Solutions workshop 1 in downloads 
::::::

::::::{attention}
This pages shows a preview of the assignment including its solution. Please fork and clone the assignment to work on it locally from [GitHub](https://github.com/CIEM5000-2025/practice-assignments)
::::::

During today's workshop you'll implement and check missing components, and solve a complicated frame.

