# Additional assignments

::::::{versionadded} v2025.2.0 After workshop 2
Solutions additional assignments in downloads 
::::::

::::::{attention}
This pages shows a preview of the assignments including their solution. Please fork and clone the assignment to work on it locally from [GitHub](https://github.com/CIEM5000-2025/practice-assignments)
::::::

Additional assignments are provided to extend your implementation of the matrix method and apply it to other structures.

```{custom_download_link} https://github.com/CIEM5000-2025/practice-assignments
:text: "All files practice assignments"
:replace_default: "False"
```

```{custom_download_link} https://github.com/CIEM5000-2025/practice-assignments/tree/solution_additional
:text: "All files practice assignments with solutions additional assignments"
:replace_default: "False"
```