export * from './types';
export * from './thebe';
export declare function setupGlobals(): void;
