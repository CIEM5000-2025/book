selector_to_html = {"a[href=\"#size-preserving-approach\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Size-preserving approach<a class=\"headerlink\" href=\"#size-preserving-approach\" title=\"Link to this heading\">#</a></h2><p>An alternative approach is to modify the equations such that the system is not reordered and the size is preserved. This can be done by replacing the line which includes the non-zero Dirichlet boundary condition with the boundary conditions itself, i.e. for a system of 3 equations:</p>", "a[href=\"#id2\"]": "<h3 class=\"tippy-header\" style=\"margin-top: 0;\">Static condensation<a class=\"headerlink\" href=\"#id2\" title=\"Link to this heading\">#</a></h3><p>Our constrained degrees of freedom are <span class=\"math notranslate nohighlight\">\\(u_1\\)</span> and <span class=\"math notranslate nohighlight\">\\(u_3\\)</span>, while <span class=\"math notranslate nohighlight\">\\(u_2\\)</span> is free:</p>", "a[href=\"#example\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Example<a class=\"headerlink\" href=\"#example\" title=\"Link to this heading\">#</a></h2><p>Let us use what we have just learned on a simple example:</p>", "a[href=\"#non-zero-dirichlet-boundary-conditions\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Non-zero Dirichlet boundary conditions<a class=\"headerlink\" href=\"#non-zero-dirichlet-boundary-conditions\" title=\"Link to this heading\">#</a></h1><p>In <a class=\"reference internal\" href=\"../lecture1/directly.html\"><span class=\"std std-doc\">Setting up global equations directly</span></a> we defined how to handle Dirichlet boundary conditions which enforce a displacement of <span class=\"math notranslate nohighlight\">\\(0\\)</span> by striking the corresponding row/column in the final system. However, this approach doesn\u2019t work with nonzero displacements.</p>", "a[href=\"#id3\"]": "<h3 class=\"tippy-header\" style=\"margin-top: 0;\">Size-preserving approach<a class=\"headerlink\" href=\"#id3\" title=\"Link to this heading\">#</a></h3><p>Now let\u2019s apply the alternative approach. First, let\u2019s set the <span class=\"math notranslate nohighlight\">\\(u_1 = 0\\)</span>:</p>", "a[href=\"element_loads.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Element loads<a class=\"headerlink\" href=\"#element-loads\" title=\"Link to this heading\">#</a></h1><p>As the matrix method is a discrete approach, nodal loads were treated with ease. However, what to do with continuous loads or loads which are not applied at the nodes?</p>", "a[href=\"#static-condensation\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Static condensation<a class=\"headerlink\" href=\"#static-condensation\" title=\"Link to this heading\">#</a></h2><p>To apply nonzero constraints we can partition the system:</p>", "a[href=\"../lecture1/directly.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Setting up global equations directly<a class=\"headerlink\" href=\"#setting-up-global-equations-directly\" title=\"Link to this heading\">#</a></h1><p>Now that you\u2019ve seen the final matrix formulation, let\u2019s set up a procedure to find it directly!</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
