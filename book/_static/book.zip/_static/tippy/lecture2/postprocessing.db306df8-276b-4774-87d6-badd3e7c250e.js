selector_to_html = {"a[href=\"#postprocessing-for-continuum-fields\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Postprocessing for continuum fields<a class=\"headerlink\" href=\"#postprocessing-for-continuum-fields\" title=\"Link to this heading\">#</a></h1><p>Up until now, we\u2019ve only looked at discrete results: nodal displacement and support reactions. However, these results can be used to obtain the continuum field.</p>", "a[href=\"element_loads.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Element loads<a class=\"headerlink\" href=\"#element-loads\" title=\"Link to this heading\">#</a></h1><p>As the matrix method is a discrete approach, nodal loads were treated with ease. However, what to do with continuous loads or loads which are not applied at the nodes?</p>", "a[href=\"../workshop1/Workshop_1_Apply.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Apply<a class=\"headerlink\" href=\"#apply\" title=\"Link to this heading\">#</a></h1><p>In this notebook you will work on a homework assignment involving a Vierendeel frame.</p><p>Our matrix method implementation is now completely stored in a local package, consisting of three classes.</p>", "a[href=\"../lecture1/single_element.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Force-displacement relations single extension element<a class=\"headerlink\" href=\"#force-displacement-relations-single-extension-element\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"../lecture1/displacement.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how you can solve structure using nodal displacements. However, the approach was still very problem-dependent. As proposed, the matrix method solves this by defining a default element which can be solved for a priori.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
