selector_to_html = {"a[href=\"#lecture-2\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Lecture 2<a class=\"headerlink\" href=\"#lecture-2\" title=\"Link to this heading\">#</a></h1><p>During today\u2019s lesson you\u2019ll wrap up the discussion on the Matrix Method for statics and implement in code some new content. You\u2019ll be given the last theoretical details of the method, including how to consider element loads, non-zero Dirichlet boundary conditions and postprocessing for support reactions and element fields.</p><p>This lecture is given by Iuri Rocha.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
