selector_to_html = {"a[href=\"#exercise_beam\"]": "<div class=\"exercise admonition\" id=\"exercise_beam\">\n<p class=\"admonition-title\">Exercise (Beam)</p>\n<section id=\"exercise-content\">\n<p>Solve this problem.</p>\n<div class=\"cell tag_thebe-remove-input-init docutils container\">\n<div class=\"cell_input docutils container\">\n<div class=\"highlight-ipython3 notranslate\"><div class=\"highlight\"><pre><span></span><span class=\"kn\">import</span><span class=\"w\"> </span><span class=\"nn\">matplotlib</span><span class=\"w\"> </span><span class=\"k\">as</span><span class=\"w\"> </span><span class=\"nn\">plt</span>\n<span class=\"kn\">import</span><span class=\"w\"> </span><span class=\"nn\">numpy</span><span class=\"w\"> </span><span class=\"k\">as</span><span class=\"w\"> </span><span class=\"nn\">np</span>\n<span class=\"n\">sys</span><span class=\"o\">.</span><span class=\"n\">path</span><span class=\"o\">.</span><span class=\"n\">insert</span><span class=\"p\">(</span><span class=\"mi\">1</span><span class=\"p\">,</span> <span class=\"s1\">'/matrixmethod_solution'</span><span class=\"p\">)</span>\n<span class=\"kn\">import</span><span class=\"w\"> </span><span class=\"nn\">matrixmethod_solution</span><span class=\"w\"> </span><span class=\"k\">as</span><span class=\"w\"> </span><span class=\"nn\">mm</span>\n<span class=\"o\">%</span><span class=\"k\">config</span> InlineBackend.figure_formats = ['svg']\n</pre></div>\n</div>\n</div>\n</div>\n<div class=\"cell tag_disable-execution-cell docutils container\">\n<div class=\"cell_input docutils container\">\n<div class=\"highlight-ipython3 notranslate\"><div class=\"highlight\"><pre><span></span><span class=\"kn\">import</span><span class=\"w\"> </span><span class=\"nn\">numpy</span><span class=\"w\"> </span><span class=\"k\">as</span><span class=\"w\"> </span><span class=\"nn\">np</span>\n<span class=\"kn\">import</span><span class=\"w\"> </span><span class=\"nn\">matplotlib</span><span class=\"w\"> </span><span class=\"k\">as</span><span class=\"w\"> </span><span class=\"nn\">plt</span>\n<span class=\"kn\">import</span><span class=\"w\"> </span><span class=\"nn\">matrixmethod</span><span class=\"w\"> </span><span class=\"k\">as</span><span class=\"w\"> </span><span class=\"nn\">mm</span>\n<span class=\"o\">%</span><span class=\"k\">config</span> InlineBackend.figure_formats = ['svg']\n</pre></div>\n</div>\n</div>\n</div>\n<div class=\"cell docutils container\">\n<div class=\"cell_input docutils container\">\n<div class=\"highlight-ipython3 notranslate\"><div class=\"highlight\"><pre><span></span><span class=\"c1\">#YOUR_CODE_HERE</span>\n</pre></div>\n</div>\n</div>\n</div>\n</section>\n</div>", "a[href=\"#beam\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Beam<a class=\"headerlink\" href=\"#beam\" title=\"Link to this heading\">#</a></h1><p>Given is the following beam <span id=\"id1\">[<a class=\"reference internal\" href=\"../references.html#id6\" title=\"Hans Welleman from Delft University of Technology. Cm5 (cie4190) - contents of lectures - lecture material - part 5: matrix method. https://icozct.tudelft.nl/TUD_CT/CM5/collegestof/, 2022.\">HansWfDUoTechnology22</a>]</span>:</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
