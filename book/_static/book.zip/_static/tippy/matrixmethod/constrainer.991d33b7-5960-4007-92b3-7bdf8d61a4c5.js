selector_to_html = {"a[href=\"../workshop2/Workshop_2_Implement.html#2_exercise3.1\"]": "<div class=\"exercise admonition\" id=\"2_exercise3.1\">\n<p class=\"admonition-title\">Exercise (Workshop 2 - 3.1)</p>\n<section id=\"exercise-content\">\n<p>Add the missing pieces to the code and docstring, before you perform the checks below.</p>\n</section>\n</div>", "a[href=\"../workshop1/Workshop_1_Implement.html#exercise3.1\"]": "<div class=\"exercise admonition\" id=\"exercise3.1\">\n<p class=\"admonition-title\">Exercise (Workshop 1 - 3.1)</p>\n<section id=\"exercise-content\">\n<p>Add the missing pieces to the code, before you perform the check below</p>\n</section>\n</div>", "a[href=\"#constrainer-py\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\"><code class=\"docutils literal notranslate\"><span class=\"pre\">constrainer.py</span></code><a class=\"headerlink\" href=\"#constrainer-py\" title=\"Link to this heading\">#</a></h1>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
