selector_to_html = {"a[href=\"#elements-py\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\"><code class=\"docutils literal notranslate\"><span class=\"pre\">elements.py</span></code><a class=\"headerlink\" href=\"#elements-py\" title=\"Link to this heading\">#</a></h1>", "a[href=\"../workshop1/Workshop_1_Implement.html#exercise2.1\"]": "<div class=\"exercise admonition\" id=\"exercise2.1\">\n<p class=\"admonition-title\">Exercise (Workshop 1 - 2.1)</p>\n<section id=\"exercise-content\">\n<p>Add the missing pieces to the code in <code class=\"docutils literal notranslate\"><span class=\"pre\">./matrixmethod/elements.py</span></code>, before you perform the checks below. Do you specify your stiffness matrix in the global or local coordinate system?</p>\n</section>\n</div>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
