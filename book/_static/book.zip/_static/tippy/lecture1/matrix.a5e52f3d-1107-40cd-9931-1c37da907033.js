selector_to_html = {"a[href=\"combine.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Combine elements<a class=\"headerlink\" href=\"#combine-elements\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"single_element.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how to set up the force-displacement relations for a single element. However, to solve for complete structures you\u2019ll need to combine multiple elements.</p>", "a[href=\"single_element.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Force-displacement relations single extension element<a class=\"headerlink\" href=\"#force-displacement-relations-single-extension-element\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"displacement.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how you can solve structure using nodal displacements. However, the approach was still very problem-dependent. As proposed, the matrix method solves this by defining a default element which can be solved for a priori.</p>", "a[href=\"#combine-elements-using-matrix-formulation\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Combine elements using matrix formulation<a class=\"headerlink\" href=\"#combine-elements-using-matrix-formulation\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"combine.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how to combine multiple elements to arrive to a linear system of equation to solve the nodal displacements. However, the nodal displacements were part of <span class=\"math notranslate nohighlight\">\\(\\mathbf{f}^e\\)</span>, which doesn\u2019t allow us to solve the vector formulation directly.</p>", "a[href=\"#local-stiffness-matrix-displacement-vector-and-force-vector\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Local stiffness matrix, displacement vector and force vector<a class=\"headerlink\" href=\"#local-stiffness-matrix-displacement-vector-and-force-vector\" title=\"Link to this heading\">#</a></h2><p>In <a class=\"reference internal\" href=\"single_element.html\"><span class=\"std std-doc\">Force-displacement relations single extension element</span></a> you\u2019ve derived the following two equations relating the nodal forces and displacements:</p>", "a[href=\"#global-stiffness-matrix-displacement-vector-and-force-vector\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Global stiffness matrix, displacement vector and force vector<a class=\"headerlink\" href=\"#global-stiffness-matrix-displacement-vector-and-force-vector\" title=\"Link to this heading\">#</a></h2><p>Now let\u2019s see how to combine multiple elements using our new matrix formulation. In <a class=\"reference internal\" href=\"combine.html\"><span class=\"std std-doc\">Combine elements</span></a> you\u2019ve derived the following three equation relating the nodal displacements with external forces:</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
