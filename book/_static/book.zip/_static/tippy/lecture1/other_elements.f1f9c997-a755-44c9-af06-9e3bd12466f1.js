selector_to_html = {"a[href=\"#elemtypes\"]": "<figure class=\"align-center\" id=\"elemtypes\">\n<img alt=\"../_images/elemtypes.svg\" src=\"../_images/elemtypes.svg\"/>\n<figcaption>\n<p><span class=\"caption-number\">Fig. 11 </span><span class=\"caption-text\">Combined extension and Euler-Bernoulli element</span><a class=\"headerlink\" href=\"#elemtypes\" title=\"Link to this image\">#</a></p>\n</figcaption>\n</figure>", "a[href=\"single_element.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Force-displacement relations single extension element<a class=\"headerlink\" href=\"#force-displacement-relations-single-extension-element\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"displacement.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how you can solve structure using nodal displacements. However, the approach was still very problem-dependent. As proposed, the matrix method solves this by defining a default element which can be solved for a priori.</p>", "a[href=\"#derivation-using-sympy\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Derivation using SymPy<a class=\"headerlink\" href=\"#derivation-using-sympy\" title=\"Link to this heading\">#</a></h2><p>We can make use of software like SymPy, as we did before in <a class=\"reference internal\" href=\"recap.html#sympy-ode\"><span class=\"std std-ref\">Solving differential equation of one field using SymPy</span></a> to do the calculations in this derivation:</p>", "a[href=\"recap.html#sympy-ode\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Solving differential equation of one field using SymPy<a class=\"headerlink\" href=\"#solving-differential-equation-of-one-field-using-sympy\" title=\"Link to this heading\">#</a></h2><p>The differential equation can also be solved using SymPy:</p>", "a[href=\"#local-stiffness-matrix-euler-bernoulli-element\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Local stiffness matrix Euler-Bernoulli element<a class=\"headerlink\" href=\"#local-stiffness-matrix-euler-bernoulli-element\" title=\"Link to this heading\">#</a></h1><p>In <a class=\"reference internal\" href=\"single_element.html\"><span class=\"std std-doc\">Force-displacement relations single extension element</span></a> and <a class=\"reference internal\" href=\"matrix.html\"><span class=\"std std-doc\">Combine elements using matrix formulation</span></a> you\u2019ve seen how to derive the local stiffness matrix for a simple extension element. But can you do the same for other elements?</p>", "a[href=\"matrix.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Combine elements using matrix formulation<a class=\"headerlink\" href=\"#combine-elements-using-matrix-formulation\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"combine.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how to combine multiple elements to arrive to a linear system of equation to solve the nodal displacements. However, the nodal displacements were part of <span class=\"math notranslate nohighlight\">\\(\\mathbf{f}^e\\)</span>, which doesn\u2019t allow us to solve the vector formulation directly.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
