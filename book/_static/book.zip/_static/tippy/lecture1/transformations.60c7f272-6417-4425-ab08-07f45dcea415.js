selector_to_html = {"a[href=\"#transformation-for-stiffness-matrix\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Transformation for stiffness matrix<a class=\"headerlink\" href=\"#transformation-for-stiffness-matrix\" title=\"Link to this heading\">#</a></h2><p>Using the known transformation for the first-order tensors <span class=\"math notranslate nohighlight\">\\(\\mathbf{u}\\)</span> and <span class=\"math notranslate nohighlight\">\\(\\mathbf{f}\\)</span> the transformation matrix for the second-order tensor <span class=\"math notranslate nohighlight\">\\(\\mathbf{K}\\)</span> can be derived:</p>", "a[href=\"#transformation-for-a-complete-element\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Transformation for a complete element<a class=\"headerlink\" href=\"#transformation-for-a-complete-element\" title=\"Link to this heading\">#</a></h2><p>To transform a complete element, the displacements of both endpoints have to be transformed, while the rotations are independent of the element orientation:</p>", "a[href=\"#transformation-for-an-arbitrary-vector\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Transformation for an arbitrary vector<a class=\"headerlink\" href=\"#transformation-for-an-arbitrary-vector\" title=\"Link to this heading\">#</a></h1><p>For an arbitrary vector <span class=\"math notranslate nohighlight\">\\(v\\)</span> with two components, the transformation matrix can be derived by comparing the vector\u2019s components in the local (<span class=\"math notranslate nohighlight\">\\(v_{\\bar x}, v_{\\bar z}\\)</span>) and global (<span class=\"math notranslate nohighlight\">\\(v_x,v_z\\)</span>) coordinate system:</p>", "a[href=\"#transformations\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Transformations<a class=\"headerlink\" href=\"#transformations\" title=\"Link to this heading\">#</a></h1><p>Up until now we didn\u2019t care about the orientation of elements. Actually, all elements had exactly the same orientation. But how do deal with elements in a different orientation?</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
