selector_to_html = {"a[href=\"recap.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Recap differential equations for structures<a class=\"headerlink\" href=\"#recap-differential-equations-for-structures\" title=\"Link to this heading\">#</a></h1><p>Let\u2019s recap how to solve a structure using differential equations.</p>", "a[href=\"#force-displacement-relations-single-extension-element\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Force-displacement relations single extension element<a class=\"headerlink\" href=\"#force-displacement-relations-single-extension-element\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"displacement.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how you can solve structure using nodal displacements. However, the approach was still very problem-dependent. As proposed, the matrix method solves this by defining a default element which can be solved for a priori.</p>", "a[href=\"displacement.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Recap displacement method<a class=\"headerlink\" href=\"#recap-displacement-method\" title=\"Link to this heading\">#</a></h1><p>In the previous <a class=\"reference internal\" href=\"recap.html\"><span class=\"std std-doc\">chapter</span></a> you\u2019ve seen how solving for integration constants because a labour-intensive process for more complicated structures. A way of circumventing that is solving for nodal displacements! You might have seen that before when solving statically indeterminate structures using the displacement method!</p>", "a[href=\"#extensionelement\"]": "<figure class=\"align-center\" id=\"extensionelement\">\n<img alt=\"../_images/extensionelement.svg\" src=\"../_images/extensionelement.svg\"/>\n<figcaption>\n<p><span class=\"caption-number\">Fig. 6 </span><span class=\"caption-text\">Single extension element</span><a class=\"headerlink\" href=\"#extensionelement\" title=\"Link to this image\">#</a></p>\n</figcaption>\n</figure>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
