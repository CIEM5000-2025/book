selector_to_html = {"a[href=\"course_information.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Learning objectives, activities and assessment \ud83d\udca1<a class=\"headerlink\" href=\"#learning-objectives-activities-and-assessment\" title=\"Link to this heading\">#</a></h1><h2>Learning objectives<a class=\"headerlink\" href=\"#learning-objectives\" title=\"Link to this heading\">#</a></h2><p>At the end of the statics part of this module, you show to be able to:</p>", "a[href=\"#id2\"]": "<figure class=\"align-default\" id=\"id2\">\n<a class=\"dark-light reference internal image-reference\" href=\"https://www.wiwa-lokal.de/wp-content/uploads/2017/11/Br%C3%BCcke.jpg\"><img alt=\"https://www.wiwa-lokal.de/wp-content/uploads/2017/11/Br%C3%BCcke.jpg\" class=\"dark-light\" src=\"https://www.wiwa-lokal.de/wp-content/uploads/2017/11/Br%C3%BCcke.jpg\" style=\"width: 400px;\"/></a>\n<figcaption>\n<p><span class=\"caption-number\">Fig. 17 </span><span class=\"caption-text\"><span id=\"id1\">WiWa-Lokal [<a class=\"reference internal\" href=\"references.html#id7\" title=\"WiWa-Lokal. Walldorf: illumination f\u00fcr die br\u00fccke zum industriegebiet. https://www.wiwa-lokal.de/walldorf-illumination-fuer-die-bruecke-zum-industriegebiet/, November 2017.\">WiWaLokal17</a>]</span> (Foto: Pfeifer)</span><a class=\"headerlink\" href=\"#id2\" title=\"Link to this image\">#</a></p>\n</figcaption>\n</figure>", "a[href=\"#graded-assignment\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Graded assignment<a class=\"headerlink\" href=\"#graded-assignment\" title=\"Link to this heading\">#</a></h1><p>When you\u2019ve finished the workshops, you can start with the graded assignment. The process is very similar to the workshops, but now there\u2019s a deadline and you\u2019re required to write a report. You\u2019re going to solve the following model for displacements and internal forces using the Matrix Method.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
