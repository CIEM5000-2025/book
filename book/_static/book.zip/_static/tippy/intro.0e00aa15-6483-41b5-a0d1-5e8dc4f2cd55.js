selector_to_html = {"a[href=\"#home\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Home<a class=\"headerlink\" href=\"#home\" title=\"Link to this heading\">#</a></h1><p>Welcome to the submodule on the Matrix Method for Statics, part of Unit 2 of CIEM5000 Course base Structural Engineering at Delft University of Technology.</p><p>This TeachBook contains the material for the course.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
