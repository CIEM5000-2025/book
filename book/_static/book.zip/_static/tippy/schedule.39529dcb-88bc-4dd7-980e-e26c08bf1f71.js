selector_to_html = {"a[href=\"lecture2.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Lecture 2<a class=\"headerlink\" href=\"#lecture-2\" title=\"Link to this heading\">#</a></h1><p>During today\u2019s lesson you\u2019ll wrap up the discussion on the Matrix Method for statics and implement in code some new content. You\u2019ll be given the last theoretical details of the method, including how to consider element loads, non-zero Dirichlet boundary conditions and postprocessing for support reactions and element fields.</p><p>This lecture is given by Iuri Rocha.</p>", "a[href=\"#course-schedule\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Course schedule \ud83d\udcc5<a class=\"headerlink\" href=\"#course-schedule\" title=\"Link to this heading\">#</a></h1><p>See the schedule below for the different weeks. Clicking the links will take you to the relevant content pages.</p>", "a[href=\"lecture1.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Lecture 1<a class=\"headerlink\" href=\"#lecture-1\" title=\"Link to this heading\">#</a></h1><p>During today\u2019s lesson we\u2019ll get started with the basics of the matrix method: you will be introduced to the Matrix Method for solving combinations of 1D elements in statics. You\u2019ll review how we solved single- and multiple-field problems in statics during Q2, and how you might have solved statically indeterminate structures using the displacement method. We\u2019ll see how that procedure can be streamlined and optimized for computer code. Following you\u2019ll be presented the basic concepts of the Matrix Method: Obtaining element stiffness matrices, local-global transformations, assembly and postprocessing. The lecture will be finalized by arriving at an abstraction of the Matrix Method that makes it readily implementable in computer code with the help of Object Oriented Programming (OOP).</p><p>This lecture is given by Tom van Woudenberg.</p>", "a[href=\"additional.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Additional assignments<a class=\"headerlink\" href=\"#additional-assignments\" title=\"Link to this heading\">#</a></h1><p>Additional assignments are provided to extend your implementation of the matrix method and apply it to other structures.</p>", "a[href=\"workshop1.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Workshop 1<a class=\"headerlink\" href=\"#workshop-1\" title=\"Link to this heading\">#</a></h1><p>During today\u2019s workshop you\u2019ll implement and check missing components, and solve a complicated frame.</p>", "a[href=\"assignment.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Graded assignment<a class=\"headerlink\" href=\"#graded-assignment\" title=\"Link to this heading\">#</a></h1><p>When you\u2019ve finished the workshops, you can start with the graded assignment. The process is very similar to the workshops, but now there\u2019s a deadline and you\u2019re required to write a report. You\u2019re going to solve the following model for displacements and internal forces using the Matrix Method.</p>", "a[href=\"workshop2.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Workshop 2<a class=\"headerlink\" href=\"#workshop-2\" title=\"Link to this heading\">#</a></h1><p>During today\u2019s workshop you\u2019ll extend your implementation of the matrix method.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
