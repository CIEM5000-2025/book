selector_to_html = {"a[href=\"#the-node-class\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">1. The Node class<a class=\"headerlink\" href=\"#the-node-class\" title=\"Link to this heading\">#</a></h2><p>The <code class=\"docutils literal notranslate\"><span class=\"pre\">Node</span></code> class from last week is unchanged and complete</p>", "a[href=\"#the-element-class\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">2. The Element class<a class=\"headerlink\" href=\"#the-element-class\" title=\"Link to this heading\">#</a></h2><p>The implementation is incomplete:</p>", "a[href=\"#the-constrainer-class\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">3. The Constrainer class<a class=\"headerlink\" href=\"#the-constrainer-class\" title=\"Link to this heading\">#</a></h2><p>We\u2019re going to expand our Constrainer class, but the implementation is incomplete:</p>", "a[href=\"#implementation\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Implementation<a class=\"headerlink\" href=\"#implementation\" title=\"Link to this heading\">#</a></h1><p>In this notebook you will continue to implement the matrix method and check it with some sanity checks.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
