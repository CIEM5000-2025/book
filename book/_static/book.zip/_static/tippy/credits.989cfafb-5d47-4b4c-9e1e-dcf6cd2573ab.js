selector_to_html = {"a[href=\"#external-resources\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">External resources<a class=\"headerlink\" href=\"#external-resources\" title=\"Link to this heading\">#</a></h2><p>Parts of this book are taken from other external resources and reused in various ways. If an author is not listed on a particular page, it is by the Authors. Page <a class=\"reference internal\" href=\"lecture2/fem.html\"><span class=\"std std-doc\">Finite element method vs. Matrix Method</span></a> includes code from <span id=\"id2\">MUDE Teachers and the Student Army from Delft University of Technology [<a class=\"reference internal\" href=\"references.html#id3\" title=\"MUDE Teachers and the Student Army from Delft University of Technology. Mude book. https://mude.citg.tudelft.nl/2024/book/fem/matrix.html, 2024.\">MUDETatSAfDUoTechnology24a</a>]</span>. Original content is licensed under CC BY.</p>", "a[href=\"#how-the-book-is-made\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">How the book is made<a class=\"headerlink\" href=\"#how-the-book-is-made\" title=\"Link to this heading\">#</a></h2><p>This book is created using open source tools: it is a JupyterBook that is written using Markdown and Jupyter notebooks. Additional tooling is used from the <a class=\"reference external\" href=\"https://teachbooks.io/\">TeachBooks initiative</a> to enhance the editing and reading experience. The files are stored on a <a class=\"reference external\" href=\"https://github.com/CIEM5000-2025/book\">public GitHub repository</a>. The website can be viewed at <a class=\"reference external\" href=\"https://ciem5000-2025.github.io/book/\">https://ciem5000-2025.github.io/book/</a>. View the repository README file or contact the authors for additional information.</p>", "a[href=\"lecture2/fem.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Finite element method vs. Matrix Method<a class=\"headerlink\" href=\"#finite-element-method-vs-matrix-method\" title=\"Link to this heading\">#</a></h1><p>You\u2019ve seen the finite element method before, which could be used to solve similar problems. But what are the differences?</p>", "a[href=\"#credits-and-license\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Credits and License<a class=\"headerlink\" href=\"#credits-and-license\" title=\"Link to this heading\">#</a></h1><p>You can refer to this book as:</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
