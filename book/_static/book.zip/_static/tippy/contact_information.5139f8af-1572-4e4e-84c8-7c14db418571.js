selector_to_html = {"a[href=\"#tom-van-woudenberg\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Tom van Woudenberg<a class=\"headerlink\" href=\"#tom-van-woudenberg\" title=\"Link to this heading\">#</a></h2>", "a[href=\"#iuri-rocha\"]": "<h2 class=\"tippy-header\" style=\"margin-top: 0;\">Iuri Rocha<a class=\"headerlink\" href=\"#iuri-rocha\" title=\"Link to this heading\">#</a></h2>", "a[href=\"#contact-information\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">Contact information \ud83d\udcac<a class=\"headerlink\" href=\"#contact-information\" title=\"Link to this heading\">#</a></h1><p>This submodule is taught by Tom van Woudenberg and Iuri Rocha. Please contact us if you\u2019ve any questions, feedback or when you\u2019ve personal circumstances which we should know.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`main ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: false,
                placement: 'auto-start', maxWidth: 500, interactive: true, boundary: document.body, appendTo: document.body,
                onShow(instance) {MathJax.typesetPromise([instance.popper]).then(() => {});},
            });
        };
    };
    console.log("tippy tips loaded!");
};
